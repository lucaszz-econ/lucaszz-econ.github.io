# Replication instruction for Python

## Contents

- `requirements.txt` – Python dependencies
- `README for Python` – Instructions (this file)

## Environment

This notebook was developed with:

- Python 3.11.9
- Jupyter Notebook
- pandas 2.1.4
- numpy 1.26.2
- scipy 1.11.4
- matplotlib 3.8.2
- scikit-learn 1.3.2
- joblib 1.3.2

## Setup Instructions

### 1. Create and activate a virtual environment

#### macOS/Linux:

python3 -m venv venv
source venv/bin/activate

#### Windows:

python -m venv venv
venv\Scripts\activate

### 2. Install dependencies

pip install -r requirements.txt

### 3. Launch Jupyter Notebook

jupyter notebook

